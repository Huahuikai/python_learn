create definer = root@localhost view cs_kc as
select `xscj`.`xs`.`学号` AS `学号`, `xscj`.`xs`.`姓名` AS `姓名`, `xscj`.`xs`.`总学分` AS `总学分`
from `xscj`.`xs`
where (`xscj`.`xs`.`专业名` = '计算机');

