create definer = root@localhost view cs_xs as
select `xscj`.`xs`.`学号`     AS `学号`,
       `xscj`.`xs`.`姓名`     AS `姓名`,
       `xscj`.`xs`.`专业名`   AS `专业名`,
       `xscj`.`xs`.`性别`     AS `性别`,
       `xscj`.`xs`.`出生时间` AS `出生时间`,
       `xscj`.`xs`.`总学分`   AS `总学分`,
       `xscj`.`xs`.`照片`     AS `照片`,
       `xscj`.`xs`.`备注`     AS `备注`
from `xscj`.`xs`
where (`xscj`.`xs`.`专业名` = '计算机');

-- comment on column cs_xs.性别 not supported: 1为男 0为女

