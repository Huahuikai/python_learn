create definer = root@localhost trigger delete_account
    after delete
    on account
    for each row
BEGIN 
DELETE from orders where userid = old.userid;
END;

