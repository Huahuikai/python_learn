create definer = root@localhost view emp_v1 as
select `yuangong`.`emp`.`id`          AS `id`,
       `yuangong`.`emp`.`workno`      AS `workno`,
       `yuangong`.`emp`.`name`        AS `name`,
       `yuangong`.`emp`.`gender`      AS `gender`,
       `yuangong`.`emp`.`age`         AS `age`,
       `yuangong`.`emp`.`idcard`      AS `idcard`,
       `yuangong`.`emp`.`workaddress` AS `workaddress`,
       `yuangong`.`emp`.`entrydate`   AS `entrydate`
from `yuangong`.`emp`
where (`yuangong`.`emp`.`id` < 5);

-- comment on column emp_v1.id not supported: 编号

-- comment on column emp_v1.workno not supported: 工号

-- comment on column emp_v1.name not supported: 姓名

-- comment on column emp_v1.gender not supported: 性别

-- comment on column emp_v1.age not supported: 年龄

-- comment on column emp_v1.idcard not supported: 身份证

-- comment on column emp_v1.workaddress not supported: 工作地址

-- comment on column emp_v1.entrydate not supported: 入职时间

