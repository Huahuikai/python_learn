create definer = root@localhost trigger insert_em_sa
    after insert
    on employees
    for each row
BEGIN
INSERT into salary VALUES(new.`员工编号`,0,0);
END;

