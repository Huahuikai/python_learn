create definer = root@localhost view cs_kc_avg as
select `xscj`.`cs_kc`.`学号` AS `学号`, round(avg(`xscj`.`cs_kc`.`成绩`), 0) AS `round(avg(成绩))`
from `xscj`.`cs_kc`
group by `xscj`.`cs_kc`.`学号`;

