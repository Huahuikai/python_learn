create definer = root@localhost trigger DELETE_yg
    after delete
    on employees
    for each row
    DELETE FROM salary where `员工编号` = old.`员工编号`;

