create definer = root@localhost view emp_view2 as
select `yggl`.`employees`.`员工编号`   AS `员工编号`,
       `yggl`.`employees`.`姓名`       AS `姓名`,
       `yggl`.`departments`.`部门名称` AS `部门名称`,
       `yggl`.`salary`.`收入`          AS `收入`
from `yggl`.`departments`
         join `yggl`.`employees`
         join `yggl`.`salary`
where ((`yggl`.`employees`.`员工部门号` = `yggl`.`departments`.`部门编号`) and
       (`yggl`.`employees`.`员工编号` = `yggl`.`salary`.`员工编号`));

-- comment on column emp_view2.部门名称 not supported: 部门名

-- comment on column emp_view2.收入 not supported: 收入

