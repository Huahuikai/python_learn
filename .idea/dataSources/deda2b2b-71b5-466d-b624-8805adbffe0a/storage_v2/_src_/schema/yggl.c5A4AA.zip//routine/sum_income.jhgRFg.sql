create
    definer = root@localhost procedure sum_income()
SELECT SUM(`收入`)  from salary;

