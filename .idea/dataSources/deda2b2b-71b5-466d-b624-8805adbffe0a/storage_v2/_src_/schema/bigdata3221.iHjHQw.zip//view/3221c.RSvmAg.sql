create definer = root@localhost view `3221c` as
select `bigdata3221`.`xs`.`id`     AS `id`,
       `bigdata3221`.`xs`.`name`   AS `name`,
       `bigdata3221`.`xs`.`sex`    AS `sex`,
       `bigdata3221`.`xs`.`age`    AS `age`,
       `bigdata3221`.`xs`.`xuefen` AS `xuefen`,
       `bigdata3221`.`xs_cj`.`cj`  AS `cj`
from `bigdata3221`.`xs`
         join `bigdata3221`.`xs_cj`
where (`bigdata3221`.`xs`.`id` = `bigdata3221`.`xs_cj`.`xs_id`);

