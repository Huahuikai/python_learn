create
    definer = root@localhost procedure up_yggl(IN bh char(6), IN jb tinyint)
BEGIN
CASE  jb 
	WHEN 'A' THEN update salary SET `收入` = 收入+500 WHERE `员工编号` = bh ;
	WHEN 'B' THEN update salary SET `收入` = 收入+300 WHERE `员工编号` = bh ;
	WHEN 'C' THEN update salary SET `收入`= 收入+150 WHERE `员工编号` = bh ;
	ELSE
	 update salary SET `收入`= 收入+50 WHERE `员工编号` = bh ;
END CASE;
END;

